
<div>
<body style="background-color:rgb(248, 248, 248);">
</div>
<div><html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>FINAL PROJECT</title>
    </head>
    <body>
        <p>
        <p> Eduardo JR. J. Cenabre</p> <BR>
          
        <div class="mt-2 ;", style="width: 500px; margin-left:17Cm">
            <p>
            <h1> <em> Narrative Report in Hadoop  </em> 
            </h1> </p>
        </div>
            <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:1m">
            <div class=> <img src="image/arc.jpg" style="width:1700;height:580;">
         </div>
             </div>

        <html>
        <head>
           
        </body>
        </html>
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
        
            <title>laravel</title>
        
        
            <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        
            <style>
                body {
                    font-family: 'Nunito', sans-serif;
                }
            </style>
        </head>
        <body>
           <html lang="en">
           <head>
            </head>
           <body>
            <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:1m"> 
            <p> Hadoop is an open-source framework that stores and process big data in a distributed environment using simple programming models.
                It is designed to scale up from single servers to thousands of machines, 
                 while each offers <br>
                 local computation and storage. 
                Hadoop divides a file into blocks and stores across a cluster of machines. It achieves fault tolerance by replicating the blocks on a cluster. 
                Hadoop can be used as a flexible and easy way <br>
                 for the distributed processing of large enterprise data sets. 
                Apart from humongous data, it includes structured, semi-structured, and unstructured data including Internet clickstreams records, <br>
                web server, social media posts, customer emails, mobile application logs, and sensor data from the Internet of Things (IoT).
                In sort, Big data is made simple with Hadoop. 
                So, Hadoop professionals get hired everywhere. <br>
                It is an in-demand job nowadays. <br>
        <p></p>  
           
    <p></p>
    <!DOCTYPE html>
    <html>
    <head>
     <h3>hadoop and jdk-8 version that I've download with image: </h3>
    </head>
    <body> 
        <h4>
        <button onclick="showContent()"><p><a href="https://www.youtube.com/watch?v=GfixwKmS8Ro&t=1142s">Hadoop Version</a></p></button> </h4>
        
        <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:1m">
            <script>
                function showContent() {
                  var temp = document.getElementsByTagName("template")[0];
                  var clon = temp.content.cloneNode(true);
                  document.body.appendChild(clon);
                }
                </script>
            <div class=>
                <body>
                <img src="image/hadoopversion.jpg" style="width:828;height:228;"> <br>
    </body>
    </html>
    <html>
    <head>
        <div>        <h4>
            <button onclick="showContent()"<button onclick="showContent()"><p><a href="https://www.guru99.com/install-java.html">Java Version</a></p></button> </h4></button> </h4>
            <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:1m">
                <script>
                    function showContent() {
                      var temp = document.getElementsByTagName("template")[0];
                      var clon = temp.content.cloneNode(true);
                      document.body.appendChild(clon);
                    }
                    </script>
            <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:1m"> <br>
            <img src="image/java_version.jpg" style="width:828;height:228;"> </div>
        </div>
    </head>
    <body>
        
    </body>
    </html>
    <h1></h1> 
          When I first look for the process of installation of hadoop in google I feel like it is easy to do the step but when I try installing Hadoop <br>
        it's a little bit tricky becuase both jdk-8 and hadoop have a large file and it took me an 30mins to download each of of the file. <br>
        I ensure that I downloaded the correct file of both hadoop and the pre-requisite if jdk-8. <br> 
         I tought that if I will download that jdk-8 and version of hadoop required, it will run softly but I was wrong, it really need to  <br>
        follow step by step and look if their an errror on it. But you can determine if there  is error of your installation, like  in the yarn it will to shutdown and <br>
         namenode is not running.
          <div class="ml-16">
          <div class="mt-2 text-black-600 dark:text-black-400 text-sm", style="margin-left:2.5em">
            </div>
        </body>
        </html> 
        <html >
        <head>
            <h1> Hadoop Module that I have: </h1>
            <p>
                <h4>
                    <button onclick="showContent()">HDFS</button> </h4>
                    <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:1m">
                        <script>
                            function showContent() {
                              var temp = document.getElementsByTagName("template")[0];
                              var clon = temp.content.cloneNode(true);
                              document.body.appendChild(clon);
                            }
                            </script>
                        <div class=>
                            <body>
     <p>     <div class="letter-spacing: 5px";>
    </h4> </div>
    <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm: border: 15px solid rgb(244, 248, 244);"> <p></p>
        <p>
    Hadoop Distributed File System(HDFS) can store a large quantity of structured as well as unstructured data. <br>
     HDFS provides reliable storage for data with its unique feature of Data Replication. <br>
     HDFS is highly fault-tolerant, reliable, available, scalable, distributed file system. <br>
</p>        
<div class="mt-2 text-gray-600 dark:text-gray-400 text-sm: border", style="margin-left:3cm">
    <p>
    <h1> <em> Process of Namenode and Datanode  </em> 
    </h1> </p>
</div>
<img src="image/master.jpg" style="width:828px;height:428px; border: 8px solid rgb(46, 51, 46);"> <br> <p></p>
<img src="image/cenabre.jpg" style="width:828px;height:288px; border: 8px solid rgb(58, 63, 65);"> <br> <p></p>
<img src="image/Inkeddatand.jpg" style="width:828px;height:428px; border: 8px solid rgb(39, 37, 39);"> 
</div>
</div>
        </p> <h4>
        <h4>
            <button onclick="showContent()">YARN</button> </h4>
            <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:1m">
                <script>
                    function showContent() {
                      var temp = document.getElementsByTagName("template")[0];
                      var clon = temp.content.cloneNode(true);
                      document.body.appendChild(clon);
                    }
                    </script>
        <p>
            In the YARN architecture, the processing layer is separated from the resource management layer. <br>
            it can create a split between the application manager and resource manager was the Job tracker’s <br>
             responsibility in the version of Hadoop
             YARN allows the data stored in HDFS (Hadoop Distributed File System) <br>
             to be processed and run by various data processing engines such as batch processing,
              stream processing, <br>
               interactive processing, graph processing and many more. Thus the efficiency of the system is increased with the use of YARN. <br>
               The processing of the application is scheduled in YARN through its different components. <br>
                Many different kinds of resources are also progressively allocated for optimum utilization.  <br>
                YARN helps a lot in the proper usage of the available resources, which is very necessary for the processing of a high volume of data.

        </p>
    </body>
    </html>
    <html>
    <head>
        <div>         
            <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:1m"> <br>
            <img src="image/yarn-cmd.jpg" style="width:1028;height:428;"> </div>
        </div>
    </head>
    <body>
        
    </body>
    </html>
                </div>
       
        <h4>
            <button onclick="showContent()">MapReduce</button> </h4>
            <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm:", style="margin-left:1m">
                <script>
                    function showContent() {
                      var temp = document.getElementsByTagName("template")[0];
                      var clon = temp.content.cloneNode(true);
                      document.body.appendChild(clon);
                    }
                    </script>
        <p> is a programming model, pattern within the hadoop framework that is used to access big data stored 
            in the HDFS. a core component, intergral to the hadoop framework.
        </p>  
        </body>
        </html>
                <h2> Advantages of hadoop and all the module:
                <h4><button onclick="showContent()">HADOOP_BIG DATA</button> </h4> </h2>
                <script>
                    function showContent() {
                      var temp = document.getElementsByTagName("template")[0];
                      var clon = temp.content.cloneNode(true);
                      document.body.appendChild(clon);
                    }
                    </script>
            </body>
            </html>
            <html>
            <head>
                <div>         
                    <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:1m"> <br>
                    <img src="image/advantage.jpg" style="width:1028;height:428;"> </div>
                </div>
            </head>
            <body><p>
                  * Hadoop provides a cost effective storage solution for business. <br>
                  * It facilitates businesses to easily access new data sources and tap into different types of data to produce value from that data. <br>
                  * It is a highly scalable storage platform. <br>
                  * The tools for data processing are often on the same servers where the data is located, resulting in much faster data processing. <br>
                  * Hadoop is now widely used across industries, including finance, media and entertainment, government, healthcare, information services, retail, and other industries <br>
                  * Hadoop is fault tolerance. <br>
               
                  *  When data is sent to an individual node, that data is also replicated to other nodes in the cluster, which means that in the event of failure, 
                     there is another copy available for use. <br>
                  *  Hadoop is more than just a faster, cheaper database and analytics tool. <br>
                   
                     It is designed as a scale-out architecture that can affordably store all of a company’s data for later use.</p>  
                     </p>
                   <div>
                 </div>
                 <div>
                     <div>
                         <div>
                         </form>
                           </div>
                              </div>
                                 </div>
                                </div>
<p>
    <p>
        <div class="row pad">
            <div class="col-lg-12 text-center",>
                <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:22cm"> <br>
                Copyright &copy; 2022 <strong></strong>
            </div>
            <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:21.5cm"> <br>
            ALL RIGHTS RESERVED  <strong></strong>
        </div>
    </footer>
</div>
    </p>
</p>
                                <div class="container-fluid">
                                    <div class="row">
                                      <footer class="fixed-bottom navbar-light" style="background: black;color: white;text-align: center;">
                                        <p>Thank you!</p>
                                      </footer>
                                    </div>
                                  </div><?php /**PATH C:\Users\Budget PC\Desktop\EduardoJRCenabre\IPTEG\exam\resources\views/home.blade.php ENDPATH**/ ?>